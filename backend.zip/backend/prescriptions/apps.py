from django.apps import AppConfig


class PrescriptionsConfig(AppConfig):
    name = 'prescriptions'
